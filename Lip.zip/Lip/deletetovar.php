<?php
require_once 'vendor/connect.php';

$id_tovar = $_GET['id'];

mysqli_query($connect, query:"DELETE FROM tovar WHERE `tovar`.`id_tovar` = '$id_tovar'");
header('Location:admin.php');
?>