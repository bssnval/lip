<?php
require_once 'vendor/connect.php';

$id = $_GET['id'];

mysqli_query($connect, query:"DELETE FROM users WHERE `users`.`id` = '$id'");
header('Location:admin.php');
?>