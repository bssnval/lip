<?php
require_once 'vendor/connect.php';
?>

<?php

$name = $_POST['name'];
$surname = $_POST['surname'];
$telephon = $_POST['telephon'];
$email = $_POST['email'];
$password = $_POST['password'];

mysqli_query($connect, query: "INSERT INTO `users` (`id`, `name`, `surname`, `telephon`, `email`, `password`) VALUES (NULL, '$name', '$surname', '$telephon', '$email', '$password');");  

header('Location: admin.php');

?>