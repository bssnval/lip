<?php

require_once 'vendor/connect.php';

$name = $_POST['name'];
$surname = $_POST['surname'];
$telephon = $_POST['telephon'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO users (name, surname, telephon, email, password) VALUES ('$name', '$surname', '$telephon', '$email', '$password')";

if ($connect->query($sql) === TRUE) {
header('Location: kabinet.php');
} else {
echo "Ошибка: " . $sql . "<br>" . $connect->error;
}

$connect->close();

?>