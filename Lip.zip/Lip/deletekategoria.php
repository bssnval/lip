<?php
require_once 'vendor/connect.php';

$id_kategoria = $_GET['id'];

mysqli_query($connect, query:"DELETE FROM kategoria WHERE `kategoria`.`id_kategoria` = '$id_kategoria'");
header('Location:admin.php');
?>
