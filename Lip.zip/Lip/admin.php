<?php
 require_once 'vendor/connect.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Административная панель</title>
</head>
<style>
    th, td {
        padding: 15px;
        font-size:20px;
    }

    th {
        color: #fff;
        background: #000;
        font-size:20px;
        font-family: "cuyabra-Regular\ [RUS\ by\ Zephyrus]";
    }

    td {
        color: #fff;
        background: #000;
        font-family: "cuyabra-Regular\ [RUS\ by\ Zephyrus]";
    }
</style>


<body>

    <p class="tabUser"> Таблица Пользователя: </p>
    
        <table>
        <tr>
            <th>ID</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Телефон</th>
            <th>Email</th>
            <th>Пароль</th>

        </tr>

    <?php
        $users = mysqli_query($connect, query: "SELECT * FROM `users`");
        $users = mysqli_fetch_all($users);
        foreach($users as $users) {
    ?>    
    
        <tr>
            <td><?= $users[0] ?></td>
            <td><?= $users[1] ?></td>
            <td><?= $users[2] ?></td>
            <td><?= $users[3] ?></td>
            <td><?= $users[4] ?></td>
            <td><?= $users[5] ?></td>
            <td><a href="updateusers.php?id=<?= $users[0] ?>" class="izDel">Изменить</a></td>
            <td><a href="deleteusers.php?id=<?= $users[0] ?>" class="izDel">Удалить</a></td>
        </tr>               

            <?php

        }
    ?>
    
    </table>
        
        <form action ="createusers.php" method ="post" >
            
            <p class="dobavPol"> Добавить Пользователя: </p>
            <input type="text" name="name" placeholder="Имя" class="adm"></input>
            <input type="text" name="surname" placeholder="Фамилия" class="adm"></input>
            <input type="text" name="telephon" placeholder="Телефон"class="adm"></input>
            <input type="text" name="email" placeholder="email" class="adm"></input>
            <input type="text" name="password" placeholder="Пароль" class="adm"></input>
            <button type="submit" class="adm">Добавить Пользователя</button>
        </form>





        <p class="tabUser"> Таблица Категория: </p>
    
    <table>
    <tr>
        <th>ID</th>
        <th>Категория</th>

    </tr>

<?php
    $kategoria = mysqli_query($connect, query: "SELECT * FROM `kategoria`");
    $kategoria = mysqli_fetch_all($kategoria);
    foreach($kategoria as $kategoria) {
?>    

    <tr>
        <td><?= $kategoria[0] ?></td>
        <td><?= $kategoria[1] ?></td>

        <td><a href="updatekategoria.php?id=<?= $kategoria[0] ?>" class="izDel">Изменить</a></td>
        <td><a href="deletekategoria.php?id=<?= $kategoria[0] ?>" class="izDel">Удалить</a></td>
    </tr>               

        <?php

    }
?>

</table>
    
    <form action ="createkategoria.php" method ="post" >
        
        <p class="dobavPol"> Добавить Категорию: </p>
        <input type="text" name="kategoria_name" placeholder="Название Категории" class="adm"></input>
        <button type="submit" class="adm">Добавить Категорию</button>
    </form>







        <p class="tabUser"> Таблица Товары: </p>
    
    <table>
    <tr>
        <th>id_tovar</th>
        <th>tovar_img</th>
        <th>tovar_name</th>
        <th>tovar_cena</th>
        <th>id_kategoria</th>

    </tr>

<?php
    $tovar = mysqli_query($connect, query: "SELECT tovar.*, kategoria.kategoria_name as 'Название категории' 
    FROM tovar JOIN `kategoria` ON tovar.`id_kategoria` = kategoria.`id_kategoria`;");
    $tovar = mysqli_fetch_all($tovar);
    foreach($tovar as $tovar) {
?>    

    <tr>
        <td><?= $tovar[0] ?></td>
        <td><?= $tovar[1] ?></td>
        <td><?= $tovar[2] ?></td>
        <td><?= $tovar[3] ?></td>
        <td><?= $tovar[4] ?></td>
        <td><a href="updatetovar.php?id=<?= $tovar[0] ?>" class="izDel">Изменить</a></td>
        <td><a href="deletetovar.php?id=<?= $tovar[0] ?>" class="izDel">Удалить</a></td>
    </tr>               

        <?php

    }
?>

</table>
    
    <form action ="createtovar.php" method ="post" >
        
        <p class="dobavPol"> Добавить Товар: </p>
        <input type="text" name="tovar_img" placeholder="Картинка Торвара" class="adm"></input>
        <input type="text" name="tovar_name" placeholder="Название Товара" class="adm"></input>
        <input type="text" name="tovar_cena" placeholder="Цена Товара"class="adm"></input>
        <input type="text" name="id_kategoria" placeholder="Категория Товара" class="adm"></input>
        <button type="submit" class="adm">Добавить Товар</button>
    </form>







            
    </html>
    </body>





    <!-- INSERT INTO `tovar` (`id_tovar`, `tovar_img`, `tovar_name`, `tovar_cena`, `id_kategoria`) VALUES (NULL, '1', '1', '1', '1'); -->


    <!-- SELECT tovar.*, kategoria.kategoria_name as 'Название категории' FROM tovar JOIN `kategoria` ON tovar.`id_kategoria` = kategoria.`id_kategoria`; -->