<?php

    require_once 'vendor/connect.php';

        $id_tovar=$_GET['id'];
        $tovar = mysqli_query($connect, query: "SELECT * FROM `tovar` WHERE `id_tovar` = '$id_tovar'");
        $tovar = mysqli_fetch_assoc($tovar);
    ?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>updatetovar</title>
</head>
<body>
    <h3>Update tovar<h3>
        <form action ="update-tovar.php" method ="post">
            <p> Изменить Товар </p>
            <input type="hidden" name="id_tovar" value ="<?= $tovar['id_tovar'] ?>" ></input> 
            <input type="text" name="tovar_img" placeholder="Картинка Товара" value ="<?= $tovar['tovar_img'] ?>" ></input>
            <input type="text" name="tovar_name" placeholder="Название Товара" value ="<?= $tovar['tovar_name'] ?>" ></input>
            <input type="text" name="tovar_cena" placeholder="Цена Товара" value ="<?= $tovar['tovar_cena'] ?>" ></input>
            <input type="text" name="id_kategoria" placeholder="Категория Товара" value ="<?= $tovar['id_kategoria'] ?>" ></input>
            <button type="submit">Изменить Товар</button>
        </form>
</body>