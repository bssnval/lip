<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Katalog</title>
</head>
<body>
    <header>
        <div class="container">

            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>

        <section class="main">
            <div class="container">
                <h2>Luxury   Lipsticks</h2>
                <hr class="line_lip">
            </div>
        </section>
    </header> 
    
    <div class="katalog">
        <div class="vetka_img_levo">
            <img src="img/vetka1.png" alt="vetka1" class="vetka1">
        </div>

        <div class="filter">
        <form method="post" action="rezalt.php">
            <select class="" name="filterkat" id="filterkat">
            <option class="" value="">Цвет краски:</option>
                <?php
                require_once 'vendor/connect.php';

                $Sql = "SELECT * FROM kategoria";
                $Result = $connect->query($Sql);
                if ($Result->num_rows > 0) {
                while($Row = $Result->fetch_assoc()) {
                echo "<option value='".$Row["kategoria_name"]."'>".$Row["kategoria_name"]."</option>";
                }
                }
                ?>
            </select>
            <button type="submit" name="submit">Найти</button>
        </form>
        </div>

        <div class="vetka_img_pravo">
            <img src="img/vetka2.png" alt="vetka1" class="vetka1">
        </div>
    </div>

    <section class="main">
        <div class="container">
            <h4 class="obvodka">результат поиска</h4>
        </div>
    </section>

    <?php
        require_once 'vendor/connect.php';

        if (isset($_POST['submit'])) { // Проверка на нажатие кнопки
        $kategoria = $_POST['filterkat'];

        // Фильтрация по категории
        $sql = "SELECT tovar.id_tovar, tovar.tovar_img, tovar.tovar_name, tovar.tovar_cena FROM tovar INNER JOIN kategoria ON tovar.id_kategoria = kategoria.id_kategoria WHERE kategoria.kategoria_name = '$kategoria'";

        // Выполнение запроса по категориям
        $result = $connect->query($sql);


        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo   
            "<div class='container'>
                    <div class='osob_box_kart'>
                        <div class='box_kart'>
                            <div class='box_kart_img'>
                                <img src=" . $row['tovar_img'] . "  alt='blesk' class='blesk'>
                                <hr class='line_kart'>
                                <p class='box_new_text'>" . $row['tovar_name'] . " </p>
                            </div>
                            <div class='box_cen_korz'>
                                <div class='cena'>
                                    <p class='main_text'>" . $row['tovar_cena'] . " ₽</p>
                                </div>
                                <div class='korzina'>
                                <div class=''><img src='img/korzina.png' alt='blesk' class='blesk'></div>
                                </div>
                            </div>
                        </div>";
        }
        } else {
        echo "Товар не найден";
        }
    }
    ?>

    <body>