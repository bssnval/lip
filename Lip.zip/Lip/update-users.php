<?php
require_once 'vendor/connect.php';

$id=$_POST['id'];
$name = $_POST['name'];
$surname = $_POST['surname'];
$telephon = $_POST['telephon'];
$email = $_POST['email'];
$password = $_POST['password'];



mysqli_query($connect, query: "UPDATE `users` SET `name` = '$name', `surname` = '$surname', `telephon` = '$telephon', 
`email` = '$email', `password` = '$password' WHERE `users`.`id` = '$id'");
header('Location:admin.php');
?>