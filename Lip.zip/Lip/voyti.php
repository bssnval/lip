<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Registration</title>
</head>
<body>
 
    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>


        <section class="main">
            <div class="container">
                <div class="registration">
                    <div class="reg">
                        <h3 class="title">Войти</h3>
                        <hr class="line_reg">

                    <form method="POST" action="vhod.php">
                        <div class="pole">
                            <div class="info">                              
                                <div class="E-mail">
                                    <p>E-mail</p>
                                    <input type="email" name="email" class="inp_pass" placeholder="Email"><br>
                                </div>
                            </div>
                            <p>Пароль</p>
                            <input type="password" name="password" class="inp_pass" placeholder="Пароль"><br>

                            <input type="submit" name="submit" class="btn_reg" value="Войти"><br><br>
                            <a href="registration.php" class="btn_voyti">Зарегистрироваться</a>
                        </div>
                    </form>
                </div>
                    <div class="img_reg">
                        <img src="img/liana.png" alt="liana" class="liana">
                    </div>

                </div>
            </div>
        </section>

    </header>

</body>
</html>