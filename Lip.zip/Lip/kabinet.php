<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Kabinet</title>
</head>
<body>
    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                </ul>
            </nav>
        </div>


        <section class="main">
            <div class="container">
                <h3>личный кабинет</h3>
                <hr class="line_korz">
            </div>
        </section>
    </header>  
    
    
    <section class="main">
        <div class="container">
            <div class="lichny_kabinet">
                <div class="avatar">
                    <img src="img/avatarka.png" alt="avatarka" class="avatarka"> 
                </div>

                <div class="profil">
                    <h4 class="zagolovok_kab">мой профиль</h4>
                    <div class="profil_text">
                        <p class="info_profil_text">Старшова</p>
                        <hr class="line_profil">
                        <p class="info_profil_text">Алиса</p>
                        <hr class="line_profil">
                        <p class="info_profil_text">Starshovaal@mail.ru</p>
                        <hr class="line_profil">
                        <p class="info_profil_text">8 (905) 770-84-23</p>
                        <hr class="line_profil">
                    </div>
                </div>


                <div class="box_zakazs">
                    <h4 class="zagolovok_kabinet">Заказы:</h4>
                    <div class="box_zakaz">

                        <div class="box_kart_kab">
                            <div class="box_kart_img">
                                <img src="img/blesk.png" alt="blesk" class="blesk">
                                <hr class="line_kart">
                                <p class="box_new_text">Увлажняющее масло для губ, тон 04 розовый</p>
                            </div>
                            
                            <div class="box_cen_korz">
                                <div class="cena">
                                    <p class="main_text">1799 ₽</p>
                                </div>
                            </div>
                        </div> 

                        <div class="zakaz">
                            
                                <div class="box_oformlenie_zakaza">
                                <h4 class="zagolovok_kabinet">Заказ № 1</h4>
                                    <div class="strochka">
                                        <div class="box_text_right">
                                            <p class="text_right">Дата заказа:</p>
                                        </div>
                                        <div class="box_text_left">
                                            <p class="text_left">20.11.2023</p>
                                        </div>
                                    </div>
            
                                    <div class="strochka">
                                        <div class="box_text_right">
                                            <p class="text_right">Ожидаемая доставка:</p>
                                        </div>
                                        <div class="box_text_left">
                                            <p class="text_left">29.11.2023</p>
                                        </div>
                                    </div>
            
                                    <div class="strochka">
                                        <div class="box_text_right">
                                            <p class="text_right">Пункт выдачи:</p>
                                        </div>
                                        <div class="box_text_left">
                                            <p class="text_left">3-я Владимирская 3к3</p>
                                        </div>
                                    </div>
            
                                    <div class="strochka">
                                        <div class="box_text_right">
                                            <p class="text_right">Стоимость:</p>
                                        </div>
                                        <div class="box_text_left">
                                            <p class="text_left">1 799₽</p>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </section>





    <footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>

</body>
</html>