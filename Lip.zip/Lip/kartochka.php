<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Kartochka</title>
</head>
<body>
    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                        <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>
    </header>


    <section class="main">
        <div class="container">
            <div class="box_kartochka_tovara">

                <div class="img_kartochka_tovara">
                    <img src="img/glavBlesk.png" alt="blesk" class="blesk_gyb"> 

                </div>

                <div class="box_text_kartochka_tovara">
                    <div class="text_kartochka_tovara">
                        <p class="text_kartochka_tovara_tpo">Артикул: 666666<br>
                            <br>
                            Увлажняющее масло для губ, тон 04 розовый<br>
                            <br>
                            Увлажняющее, питательное масло для лакового эффекта<br>
                            на губах c уникальной нелипкой формулой и маслом<br>
                            косточек вишни.<br>
                            <br>
                            Объем: 5,6 мл
                        </p>

                        <p class="text_kartochka_tovara_bottom">Состав:<br>
                            <br>
                            HYDROGENATED POLYCYCLOPENTADIENE, SYNTHEПC BEESWAX, DISТEARDIMONIUM HECTORITE, CI 77891<br>
                            (ПTANIUM DIOXIDE), CI 42090 (ВШЕ 1 LAKE), PROPYLENE CARBONATE, AROMA (FLAVOR), ETHYLHEXYL<br>
                            PALMITAТE, PENTAERYТHRITYL TEТRA-D1-T-BUТYL HYDROXYHYDROCINNAMAТE, MICA, BUТYLENE GLYCOL,<br>
                            CAPRYLYL GLYCOL, PHENOXYEТHANOL, SODIUM HYALURONATE, HEXYLENE GLYCOL<br>
                        </p>
                    </div>

                    <hr class="line_kartochka_tovara">
                    <div class="box_cena_kartochka_tovara">
                        <div class="cena_kartochka">
                        <p class="cena_kartochka_tovara">1799 ₽</p>
                        </div>
                        <div class="dobavit">
                            <h4>добавить в корзину</h4>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>



    <footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>



</body>
</html>