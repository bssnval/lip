<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>About</title>
</head>
<body>

    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                        <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>

        <section class="main">
            <div class="container">
                <h2>Luxury   Lipsticks</h2>
                <hr class="line_lip">
            </div>
        </section>

        <section class="main">
            <div class="container">
                <div class="proizvodstvo_zagolovok">
                    <div class="proizvodstvo">
                        <h4>производство</h4>
                    </div>
                    <div class="vetochka">
                        <img src="img/vetochka1.png" alt="vetka1" class="vetochka1">
                    </div>
                </div>
                <div class="proizvodstvo_text">
                    <div class="proizvod_text">
                        <p>
                            Производство изготовления люксовых помад для губ - это сложный и многоэтапный<br>
                            процесс. Для начала, необходимо выбрать качественные и натуральные ингредиенты,<br>
                            такие как воск, масла, пигменты и ароматизаторы. Затем, эти ингредиенты<br>
                            смешиваются в определенных пропорциях, чтобы получить желаемую текстуру и<br>
                            оттенок помады.<br>
                            <br>
                            После этого, смесь помещается в специальные формы и охлаждается, чтобы она<br>
                            застыла и приняла желаемую форму. Затем, производится упаковка помады в<br>
                            элегантные и стильные футляры, что придает продукту роскошный вид.<br>
                            <br>
                            Для люксовых помад также используются высококачественные ароматизаторы и<br>
                            пигменты, чтобы достигнуть насыщенности цвета и приятного запаха. Кроме того,<br>
                            при производстве уделяется внимание каждой детали, начиная от выбора сырья и<br>
                            заканчивая дизайном упаковки.<br>
                            <br>
                            Изготовление люксовых помад ведется на специализированных заводах, где<br>
                            соблюдаются все стандарты качества и безопасности. Каждый этап процесса<br>
                            контролируется специалистами, чтобы гарантировать высокое качество конечного<br> 
                            продукта.<br>
                        </p>
                    </div>
                <div class="box_proizvodstvo_img">
                    <img src="img/proizvodstvo.png" alt="proizvodstvo" class="proizvodstvo_img">
                </div>
                </div>

            </div>  
        </section>

    </header>




    <section class="main">
        <div class="container">
            <div class="ideal_lip_zagolovok">
                <div class="vetochka2">
                    <img src="img/vetochka1.png" alt="vetka1" class="vetochka1">
                </div>
                <div class="ideal_lip">
                    <h4>как подобрать<br>
                        идеальную помаду?</h4>
                </div>
            </div>
            <div class="box_ideal_lip_text">
                <div class="box_ideal_lip_img">
                    <img src="img/rybashka.png" alt="ideal_lip" class="ideal_lip_img">
                </div>

                <div class="ideal_lip_text">
                    <p>
                        Подбор идеальной помады - это индивидуальный процесс, зависящий от предпочтений,<br>
                        типа кожи, цвета губ и желаемого эффекта. Вот несколько шагов, которые помогут<br>
                        вам подобрать идеальную помаду:<br>
                        <br>
                        1. Учитывайте тип и состояние кожи губ. Если у вас сухие губы, то желательно<br>
                        выбирать увлажняющую или кремовую помаду. Для жирных или блестящих губ,<br>
                        подойдут матовые помады.<br>
                        <br>
                        2. Определите желаемый оттенок помады. Учитывайте цвет кожи, цвет глаз, а также<br>
                        волос. Человека с теплым оттенком кожи лучше всего подходят теплые оттенки помады,<br>
                        а для людей с холодным оттенком кожи - холодные оттенки помады.<br>
                        <br>
                        3. Рассмотрите текстуру помады. Если вам нравится блестящий или матовый эффект,<br>
                        выберите соответствующую текстуру помады.<br>
                        <br>
                        4. Не забывайте проверять помаду на свету и на вашей коже, чтобы убедиться, что<br>
                        она идеально сочетается с вашими губами.<br>
                        <br>
                        5. И, конечно же, учитывайте сезон и время суток. Например, весной и летом уместно<br>
                        выбирать светлые и яркие оттенки, а осенью и зимой - более темные и насыщенные.<br>
                        <br>
                        Кроме того, важно помнить, что подбор идеальной помады может занять некоторое<br>
                        время, поэтому будьте терпеливы и пробуйте разные варианты, пока не найдете то,<br>
                        что идеально подходит именно вам.<br>
                    </p>
                </div>
            </div>

        </div>  
    </section>
    




    <section class="main">
        <div class="container">
            <div class="history_zagolovok">
                <div class="history">
                    <h4>история создания</h4>
                </div>
                <div class="vetochka">
                    <img src="img/vetochka1.png" alt="vetka1" class="vetochka1">
                </div>
            </div>
            <div class="box_history_text">
                <div class="history_text">
                    <p>
                        В начале 20-го века в маленьком французском поселке селекционер роз Жан-Пьер<br>
                        Липари создал удивительный сорт розы с невероятно яркими и насыщенными<br>
                        цветками, которые вскоре стали его фирменным брендом. Его розы были настолько<br>
                        красивы, что их аромат и красота стали вдохновением для создания новой линии<br>
                        косметических продуктов.<br>
                        <br>
                        Жан-Пьер Липари, будучи влюбленным в красоту своих роз, решил разработать<br>
                        уникальную формулу помады для губ, которая бы отображала несравненную красоту<br>
                        его роз. Он провел множество экспериментов, используя эфирные масла и пигменты,<br>
                        чтобы добиться насыщенного цвета помады и нежной текстуры.<br>
                        <br>
                        Спустя годы тщательной работы он представил уникальную коллекцию люксовых помад<br>
                        под названием "Lip", вдохновленную его розами. Их упаковка была украшена<br>
                        изображениями роз, а цвета помады соответствовали цветам его самых известных роз.<br>
                        <br>
                        Коллекция помад Lip стала символом роскоши и красоты, завоевав любовь многих<br>
                        женщин по всему миру благодаря своей уникальной формуле, отличным качеством<br>
                        и прекрасной упаковке.<br>
                    </p>
                </div>
            <div class="box_history_img">
                <img src="img/sad.png" alt="history" class="history_img">
            </div>
            </div>

        </div>  
    </section>




    <footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>



</body>
</html>