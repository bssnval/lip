<?php require_once 'vendor/connect.php'; ?>

<?php session_start();?>

<?php
$email=$_POST["email"];
$password=$_POST["password"];


$sql = $pdo->prepare("SELECT id, email FROM users WHERE email=:email AND password=:password");
$sql->execute(array('email'=>$email,'password'=>$password));
$array=$sql->fetch(PDO::FETCH_ASSOC);
print_r($array);


if($array["id"]>0){
$_SESSION['email']=$array["email"];
header('Location: kabinet.php');
}
else{
header('Location: voyti.php');
}
?>