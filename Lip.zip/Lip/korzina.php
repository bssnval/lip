<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Korzina</title>
</head>
<body>
    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>

        <section class="main">
            <div class="container">
                <h3>Моя корзина</h3>
                <hr class="line_korz">
            </div>
        </section>
    </header>
    
    
    <section class="main">
        <div class="container">
            <div class="korzina">
                <div class="box_tovara">
                    <div class="img_tovar">
                        <img src="img/glavBlesk.png" alt="blesk" class="blesk_gyb_korz">       
                    </div>
                    <div class="vertical-line"></div>
                    <div class="text_tovara">
                        <div class="text_tovara_top">
                            <div class="info_text">
                                <p class="info_text_tovara">Увлажняющее масло для губ,<br>
                                    тон 04 розовый</p>
                            </div>
                            <div class="checkbox_box"> 
                                <input type="checkbox" class="checkbox"> 
                            </div>
                        </div>
                        
                        <div class="text_tovara_bottom">
                            <div class="text_cena_tovara">
                                <p class="text_cena">1799 ₽</p>
                            </div>
                            <div class="img_korzina">
                                <img src="img/vedro.png" alt="blesk" class="vedro">          
                            </div>
                        </div>
                    </div>
                </div>


                <div class="oformlenie_zakaza">
                    <h4 class="zagolovok_kabinet">Оформление заказа</h4>
                    <div class="box_oformlenie_zakaza">
                        <div class="strochka">
                            <div class="box_text_right">
                                <p class="text_right">Ожидаемая доставка:</p>
                            </div>
                            <div class="box_text_left">
                                <p class="text_left">29.11.2023</p>
                            </div>
                        </div>

                        <div class="strochka">
                            <div class="box_text_right">
                                <p class="text_right">Пункт выдачи:</p>
                            </div>
                            <div class="box_text_left">
                                <p class="text_left">3-я Владимирская 3к3 </p>
                            </div>
                        </div>

                        <div class="strochka">
                            <div class="box_text_right">
                                <p class="text_right">Сумма:</p>
                            </div>
                            <div class="box_text_left">
                                <p class="text_left">3 598₽</p>
                            </div>
                        </div>

                        <div class="strochka">
                            <div class="box_text_right">
                                <p class="text_right">Итого к оплате:</p>
                            </div>
                            <div class="box_text_left">
                                <p class="text_left">3 598₽</p>
                            </div>
                        </div>
                    </div>

                    <div class="oplata">
                        <h4 class="zagolovok_kabinet">оплатить</h4>
                    </div>

                </div>

            </div>

        </div>  
    </section>



    <footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>


</body>
</html>
