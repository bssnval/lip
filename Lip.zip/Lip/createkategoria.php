<?php
require_once 'vendor/connect.php';
?>

<?php

$kategoria_name = $_POST['kategoria_name'];


mysqli_query($connect, query: "INSERT INTO `kategoria` (`id_kategoria`, `kategoria_name`) VALUES (NULL, '$kategoria_name');");  

header('Location: admin.php');

?>