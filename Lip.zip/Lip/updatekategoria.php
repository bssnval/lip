<?php
    require_once 'vendor/connect.php';
    $id_kategoria  = $_GET['id'];
    $kategoria = mysqli_query( $connect, query: "SELECT * FROM `kategoria` WHERE `id_kategoria` = '$id_kategoria' ");
    $kategoria = mysqli_fetch_assoc($kategoria);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Updait</title>
</head>
<body>
<div class="container">

    <h3 class="adminka_h3">Изменить Пользователя</h3>

        <form action="update-kategoria.php" method="post">
            <input type="hidden" name="id_kategoria" value="<?= $kategoria['id_kategoria'] ?>"></input>

            <p class="adminka_p">Фио</p>
            <input class="adminka_imp" name="kategoria_name" value="<?= $kategoria['kategoria_name'] ?>"></input><br><br>

            <button class="adminka_button mnogo" type="submit">Изменить</button>
        </form>

</div>
    
</body>
</html>
