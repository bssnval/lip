<?php
require_once 'vendor/connect.php';

$id_kategoria=$_POST['id_kategoria'];
$kategoria_name = $_POST['kategoria_name'];




mysqli_query($connect, query: "UPDATE `kategoria` SET `kategoria_name` = '$kategoria_name' WHERE `kategoria`.`id_kategoria` = '$id_kategoria'");
header('Location:admin.php');
?>