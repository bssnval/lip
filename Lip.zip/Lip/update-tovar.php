<?php
require_once 'vendor/connect.php';

$id_tovar=$_POST['id'];
$tovar_img = $_POST['tovar_img'];
$tovar_name = $_POST['tovar_name'];
$tovar_cena = $_POST['tovar_cena'];
$id_kategoria = $_POST['id_kategoria'];

mysqli_query($connect, query: "UPDATE `tovar` SET `tovar_img` = '$tovar_img', `tovar_name` = '$tovar_name', `tovar_cena` = '$tovar_cen', `id_kategoria` = '$id_kategoria' WHERE `tovar`.`id_tovar` = '$id_tovar';");
header('Location:admin.php');
?>

<!-- ОШИБКА -->