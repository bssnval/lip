<?php
require_once 'vendor/connect.php';
?>

<?php

$tovar_img = $_POST['tovar_img'];
$tovar_name = $_POST['tovar_name'];
$tovar_cena = $_POST['tovar_cena'];
$id_kategoria = $_POST['id_kategoria'];

mysqli_query($connect, query: "INSERT INTO `tovar` (`id_tovar`, `tovar_img`, `tovar_name`, `tovar_cena`, `id_kategoria`) 
VALUES (NULL, '$tovar_img', '$tovar_name', '$tovar_cena', '$id_kategoria');");  

header('Location: admin.php');

?>