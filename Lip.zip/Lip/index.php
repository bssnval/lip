<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Lip</title>
</head>
<body>

    <header>
        <div class="container">
            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                        <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>

        <section class="main">
            <div class="main_boxs">
                <div class="main_box">
                   <img src="img/list1.png" alt="list" class="list"> 
                </div>
                <div class="main_box">
                    <h1>Luxury   Lipsticks</h1>
                    <hr class="line">
                    <p class="main_text">люксовые помады для губ</p>
                </div>
                <div class="main_box">
                    <img src="img/list2.png" alt="list" class="list">
                </div>
            </div>


                
        </section>

    </header>



    <section class="main">
        <div class="container">
            <div>
            <h4 class="obvodka">новинки</h4>
            </div>
            <a href="kartochka.php">
                <div class="box_news">

                    <div class="box_kart">
                        <div class="box_new">
                            <img src="img/glavBlesk.png" alt="blesk" class="blesk">
                            <hr class="line_kart">
                            <p class="box_new_text">Увлажняющее масло для губ, тон 04 розовый</p>
                        </div>
                        <div class="box_cen_korz">
                            <div class="cena">
                                <p class="main_text">1799 ₽</p>
                            </div>
                            <div class="korzina">
                                <div >
                                <img src="img/korzina.png" alt="blesk" class="korzina">
                            </div>
                            </div>
                        </div>
                    </div> 



                    <div class="box_kart">
                        <div class="box_new">
                            <img src="img/glavBlesk.png" alt="blesk" class="blesk">
                            <hr class="line_kart">
                            <p class="box_new_text">Увлажняющее масло для губ, тон 04 розовый</p>
                        </div>
                        <div class="box_cen_korz">
                            <div class="cena">
                                <p class="main_text">1799 ₽</p>
                            </div>
                            <div class="korzina">
                                <div >
                                <img src="img/korzina.png" alt="blesk" class="korzina">
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="box_kart">
                        <div class="box_new">
                            <img src="img/glavBlesk.png" alt="blesk" class="blesk">
                            <hr class="line_kart">
                            <p class="box_new_text">Увлажняющее масло<br> для губ, тон 04<br> розовый</p>
                        </div>
                        <div class="box_cen_korz">
                            <div class="cena">
                                <p class="main_text">1799 ₽</p>
                            </div>
                            <div class="korzina">
                                <div class="">
                                <img src="img/korzina.png" alt="blesk" class="korzina">
                            </div>
                            </div>
                        </div>
                    </div>


                </div>
            </a>
        </div>
    </section>


    <section class="main">
        <div class="container">
            <div class="pyc">
                <h4 class="obvodka">немного о нас</h4>
                <div class="little_about">
                    <div class="box_text_about">
                        <p class="text_about">Добро пожаловать на страницу Lip - вашего источника<br>
                            роскошных помад высочайшего качества. Мы - мировой<br>
                            лидер в производстве люксовых помад, предлагающих<br>
                            инновационные формулы, изысканные оттенки и<br>
                            роскошную упаковку.<br>
                            <br>
                            Наша миссия - создавать продукцию, обладающую<br> 
                            уникальными свойствами, которая подчеркнет вашу<br>
                            естественную красоту и придаст уверенности в любой<br>
                            ситуации. Мы используем только самые качественные<br>
                            ингредиенты, чтобы обеспечить долговременное<br>
                            увлажнение, яркий цвет и комфортное нанесение.<br>
                            Каждая помада Lip проходит тщательные испытания,<br>
                            чтобы гарантировать нашим клиентам безупречное<br>
                            качество.<br>
                            <br>
                            Мы гордимся нашими высокими стандартами качества<br>
                            и стремимся предоставить нашим клиентам<br>
                            непревзойденный уровень обслуживания. Мы ценим<br> 
                            ваше доверие, и поэтому наша цель - удовлетворить<br>
                            ваши потребности и ожидания.</p>
                    </div>
                    <div class="box_img_kamni">
                        <img src="img/kamenGroup.png" alt="kamni" class="img_kamni">
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="main">
        <div class="container">
            <h4 class="obvodka">наши магазины</h4>
            <div class="karta">
            <script  type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A661aec1f552ee0dc306b1ea60ec4a5526c8d6a331a5437ab971c58319d5c007e&amp;width=1220&amp;height=665&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
        </div>
    </section>



    <footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>


</body>
</html>