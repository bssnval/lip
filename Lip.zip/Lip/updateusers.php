<?php

    require_once 'vendor/connect.php';

        $id=$_GET['id'];
        $users = mysqli_query($connect, query: "SELECT * FROM `users` WHERE `id` = '$id'");
        $users = mysqli_fetch_assoc($users);
    ?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>updateusers</title>
</head>
<body>
    <h3>Update users<h3>
        <form action ="update-users.php" method ="post">
            <p> Изменить Пользователя </p>
            <input type="hidden" name="id" value ="<?= $users['id'] ?>" ></input> 
            <input type="text" name="name" placeholder="Имя" value ="<?= $users['name'] ?>" ></input>
            <input type="text" name="surname" placeholder="Фамилия" value ="<?= $users['surname'] ?>" ></input>
            <input type="text" name="telephon" placeholder="Телефон" value ="<?= $users['telephon'] ?>" ></input>
            <input type="text" name="email" placeholder="email" value ="<?= $users['email'] ?>" ></input>
            <input type="text" name="password" placeholder="Пароль" value ="<?= $users['password'] ?>" ></input>
            <button type="submit">Изменить Пользователя</button>
        </form>
</body>