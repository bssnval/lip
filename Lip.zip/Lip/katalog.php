<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stule.css">
    <title>Katalog</title>
</head>
<body>
    <header>
        <div class="container">

            <nav class="menu">
                <ul class="menu_wrapper">
                    <li class="menu_logo"><a href="index.php" class="menu_logo">Lip</a></li>
                </ul>
                <ul class="menu_wrapper">
                <li class="menu_nav"><a href="index.php" class="menu_nav">Главная</a></li>
                        <li class="menu_nav"><a href="katalog.php" class="menu_nav">Каталог</a></li>
                        <li class="menu_nav"><a href="about.php" class="menu_nav">О нас</a></li>
                        <li class="menu_nav_osob"><a href="korzina.php" class="menu_nav">Корзина</a></li>
                        <li class="menu_nav"><a href="registration.php" class="menu_nav"> <img src="img/lichny_kabinet.png" alt="lichny_kabinet" class="menu_img"></a></li>
                        
                </ul>
            </nav>
        </div>

        <section class="main">
            <div class="container">
                <h2>Luxury   Lipsticks</h2>
                <hr class="line_lip">
            </div>
        </section>
    </header> 
    
    <div class="katalog">
        <div class="vetka_img_levo">
            <img src="img/vetka1.png" alt="vetka1" class="vetka1">
        </div>

        <div class="filter">
        <form method="post" action="rezalt.php">
            <select class="" name="filterkat" id="filterkat">
            <option class="" value="">Категории:</option>
                <?php
                require_once 'vendor/connect.php';

                $Sql = "SELECT * FROM kategoria";
                $Result = $connect->query($Sql);
                if ($Result->num_rows > 0) {
                while($Row = $Result->fetch_assoc()) {
                echo "<option value='".$Row["kategoria_name"]."'>".$Row["kategoria_name"]."</option>";
                }
                }
                ?>
            </select>
            <button type="submit" name="submit">Найти</button>
        </form>
        </div>

        <div class="vetka_img_pravo">
            <img src="img/vetka2.png" alt="vetka1" class="vetka1">
        </div>
    </div>



<!-- начало категория блеск для губ -->


<?php
        require_once 'vendor/connect.php';



        $sql="SELECT tovar.id_tovar, tovar.tovar_name, tovar.tovar_img, tovar.tovar_cena, tovar.id_kategoria FROM tovar INNER JOIN kategoria 
        ON tovar.id_kategoria = kategoria.id_kategoria WHERE kategoria.kategoria_name = 'блеск для губ';";
        $all_tovars = $connect->query($sql);
    ?>

    <section class="main">
        <div class="container">
        <div class="pyc">
            <h4 class="obvodka">блеск для губ</h4>

            <?php
                while($row = mysqli_fetch_assoc($all_tovars)){
            ?>
            <a href="kartochka.php">
            <div class="osob_box_kart">
                <div class="box_kart">
                    <div class="box_kart_img">
                        <img src="<?php echo $row["tovar_img"]; ?>" alt="blesk" class="blesk ">
                        <hr class="line_kart">
                        <p class="box_new_text"><?php echo $row["tovar_name"]; ?></p>
                    </div>
                    <div class="box_cen_korz">
                        <div class="cena">
                            <p class="main_text"><?php echo $row["tovar_cena"]; ?>₽</p>
                        </div>
                        <div class="korzina">
                            <div class=""><img src="img/korzina.png" alt="blesk" class="blesk"></div>
                        </div>
                    </div>
                </div> 

            <?php
                }
            ?>
            </div>
            </a>
        </div> 
        </div>
    </section>

<!-- конец категория блеск для губ -->

<!-- начало категория помада для губ -->

<?php
        require_once 'vendor/connect.php';
       


        $sql="SELECT tovar.id_tovar, tovar.tovar_name, tovar.tovar_img, tovar.tovar_cena, tovar.id_kategoria FROM tovar INNER JOIN kategoria 
        ON tovar.id_kategoria = kategoria.id_kategoria WHERE kategoria.kategoria_name = 'помада для губ';";
        $all_tovars = $connect->query($sql);
    ?>

    <section class="main">
        <div class="container">
        <div class="pyc">
            <h4 class="obvodka">помада для губ</h4>

            <?php
                while($row = mysqli_fetch_assoc($all_tovars)){
            ?>
            <a href="kartochka.php">
            <div class="osob_box_kart">
                <div class="box_kart">
                    <div class="box_kart_img">
                        <img src="<?php echo $row["tovar_img"]; ?>" alt="blesk" class="blesk">
                        <hr class="line_kart">
                        <p class="box_new_text"><?php echo $row["tovar_name"]; ?></p>
                    </div>
                    <div class="box_cen_korz">
                        <div class="cena">
                            <p class="main_text"><?php echo $row["tovar_cena"]; ?>₽</p>
                        </div>
                        <div class="korzina">
                        <div class=""><img src="img/korzina.png" alt="blesk" class="blesk"></div>
                        </div>
                    </div>
                </div> 

            <?php
                }
            ?>
            </div>
            </a>
        </div>
        </div>
    </section>

<!-- конец категория помада -->

<!-- начало бальзам для губ -->


<?php
        require_once 'vendor/connect.php';
       


        $sql="SELECT tovar.id_tovar, tovar.tovar_name, tovar.tovar_img, tovar.tovar_cena, tovar.id_kategoria FROM tovar INNER JOIN kategoria 
        ON tovar.id_kategoria = kategoria.id_kategoria WHERE kategoria.kategoria_name = 'бальзам для губ';";
        $all_tovars = $connect->query($sql);
    ?>

    <section class="main">
        <div class="container">
        <div class="pyc">
            <h4 class="obvodka">бальзам для губ</h4>

            <?php
                while($row = mysqli_fetch_assoc($all_tovars)){
            ?>
            <a href="kartochka.php">
            <div class="osob_box_kart">
                <div class="box_kart">
                    <div class="box_kart_img">
                        <img src="<?php echo $row["tovar_img"]; ?>" alt="blesk" class="blesk">
                        <hr class="line_kart">
                        <p class="box_new_text"><?php echo $row["tovar_name"]; ?></p>
                    </div>
                    <div class="box_cen_korz">
                        <div class="cena">
                            <p class="main_text"><?php echo $row["tovar_cena"]; ?>₽</p>
                        </div>
                        <div class="korzina">
                        <div class=""><img src="img/korzina.png" alt="blesk" class="blesk"></div>
                        </div>
                    </div>
                </div> 

            <?php
                }
            ?>
            </div>
            </a>
        </div>
        </div>
    </section>

<!-- конец бальзам для губ -->    

<!-- начало карандаш для губ -->


<?php
        require_once 'vendor/connect.php';



        $sql="SELECT tovar.id_tovar, tovar.tovar_name, tovar.tovar_img, tovar.tovar_cena, tovar.id_kategoria FROM tovar INNER JOIN kategoria 
        ON tovar.id_kategoria = kategoria.id_kategoria WHERE kategoria.kategoria_name = 'карандаш для губ';";
        $all_tovars = $connect->query($sql);
    ?>

    <section class="main">
        <div class="container">
        <div class="pyc">
            <h4 class="obvodka">карандаш для губ</h4>

            <?php
                while($row = mysqli_fetch_assoc($all_tovars)){
            ?>
            <a href="kartochka.php">
            <div class="osob_box_kart">
                <div class="box_kart">
                    <div class="box_kart_img">
                        <img src="<?php echo $row["tovar_img"]; ?>" alt="blesk" class="blesk">
                        <hr class="line_kart">
                        <p class="box_new_text"><?php echo $row["tovar_name"]; ?></p>
                    </div>
                    <div class="box_cen_korz">
                        <div class="cena">
                            <p class="main_text"><?php echo $row["tovar_cena"]; ?>₽</p>
                        </div>
                        <div class="korzina">
                            <div class=""><img src="img/korzina.png" alt="blesk" class="blesk"></div>
                        </div>
                    </div>
                </div> 

            <?php
                }
            ?>
            </div>
            </a>
        </div>
        </div>
    </section>

<!-- конец карандаш для губ -->      

    
<footer class="footer">
        <div class="container">
            <div class="foter-displ">
                <div class="soc_seti">
                    <p class="text_soc_seti ">Мы в социальных сетях :</p>
                    <div class="img_soc_seti">
                        <img src="img/telegram.png" alt="telegram" class="so_seti">
                        <img src="img/vk.png" alt="vk" class="so_seti">
                        <img src="img/youtube.png" alt="youtube" class="so_seti">       
                    </div>
                </div>
                <div class="telephone">
                    <p class="text_telephone">наши контактные данные :<br>
                    <br><br>
                    +7 (495) 777 - 77 - 77<br>
                    +7 (495) 222 - 22 - 22<br>
                    </p>
                </div>
                <div class="footer_img">
                    <img src="img/list_footer.png" alt="list" class="list_footer">       
                </div>
            </div>
        </div>
    </footer>



</body>
</html>